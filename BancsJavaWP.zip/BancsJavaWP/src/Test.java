import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Test {

    private static final boolean LOG_HEADERS = true;

    public static void main(String[] args) {
        WebClient webClient = WebClient.builder()
            .baseUrl("https://demoapps.tcsbancs.com/Core/accountManagement")
            .build();

        AccountRequest request = new AccountRequest("123456", "SAVINGS", "INR", 1000);

        String userId = "testuser";
        String languageCode = "EN";

        long startTime = System.currentTimeMillis();

        webClient.post()
            .uri(uriBuilder -> uriBuilder
                .path("/account")
                .queryParam("userid", userId)
                .queryParam("languagecode", languageCode)
                .build())
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .bodyValue(request)
            .exchangeToMono(response -> handleAndLogResponse(response, startTime))
            .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(2))
                .filter(ex -> {
                    System.out.println("🔁 Retrying due to: " + ex.getMessage());
                    return true;
                }))
            .doOnError(e -> logToFile("error.log", "❌ Final failure: " + e.getMessage()))
            .subscribe();

        System.out.println("➡️ API fired asynchronously. Main thread continues...");
    }

    private static Mono<Void> handleAndLogResponse(ClientResponse response, long startTime) {
        int statusCode = response.statusCode().value();
        long durationMs = System.currentTimeMillis() - startTime;

        return response.bodyToMono(String.class).flatMap(body -> {
            StringBuilder log = new StringBuilder();
            log.append("🕒 Response Time: ").append(durationMs).append(" ms\n")
               .append("🔢 Status Code: ").append(statusCode).append("\n")
               .append("📦 Response Body:\n").append(body).append("\n");

            if (LOG_HEADERS) {
                log.append("📬 Headers:\n");
                response.headers().asHttpHeaders().forEach((k, v) ->
                    log.append("  ").append(k).append(": ").append(v).append("\n"));
            }

            if (statusCode == 401 || statusCode == 403 || statusCode == 404 || statusCode >= 500) {
                logToFile("error.log", log.toString());
            } else {
                logToFile("success.log", log.toString());
            }

            return Mono.empty();
        });
    }

    private static void logToFile(String fileName, String content) {
        try {
            String path = Paths.get(fileName).toAbsolutePath().toString();
            FileWriter writer = new FileWriter(path, true);
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("\n[" + timestamp + "]\n" + content + "\n");
            writer.close();
            System.out.println("📝 Logged to " + fileName);
        } catch (IOException e) {
            System.err.println("⚠️ Failed to write log: " + e.getMessage());
        }
    }
}
