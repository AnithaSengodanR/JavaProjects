package com.tcs.bancs.RestApiUtility;

import org.apache.log4j.Logger;
import com.tcs.bfsarch.util.ExceptionUtil;
import com.tcs.mastercraft.mctype.MasterCraftVector;
import com.tcs.mastercraft.mctype.ServerContext;
import com.tcs.mastercraft.mcutil.MasterCraftException;
import ErrorMessages.ErrMessages;

public class ExternalServiceCallerClass {

    private static final Logger log = Logger.getLogger("BancsOnline." + ExternalServiceCallerClass.class);

    StringBuffer REQUEST_URL;
    
    
    public StringBuffer getREQUEST_URL() {
        return REQUEST_URL;
    }

    public void setREQUEST_URL(StringBuffer rEQUEST_URL) {
        REQUEST_URL = rEQUEST_URL;
    }
    /**
     * Method to call external service
     * @param externalServiceSb
     * @param inpVec
     * @param returnVectorObj
     * @return
     */
    public  int invokeExternalService(StringBuffer externalServiceSb, MasterCraftVector inpVec,
            MasterCraftVector returnVectorObj) {

        String externalService = externalServiceSb.toString();
        String serviceName = externalServiceSb.toString();
        int ret = 0;
        StringBuffer request_url = null;
        if(this.getREQUEST_URL() != null &&  (!(this.getREQUEST_URL().toString().isEmpty() )))
        {
         request_url = this.getREQUEST_URL();
        }
        ServiceMapping unmarshalledObjFromDsl = new ServiceMapping();
       // RestAPIUtil restAPIUtil = new RestAPIUtil();
		RestAPICall restapicall = new RestAPICall();
        if (log.isDebugEnabled()) {
            log.debug("invokeExternalService : start - internalService" + externalService + ":inpVec" + inpVec);
        }
        if ((externalService == null) || (externalService.trim().length() == 0)) {
            log.error("Service name not specified");
            ErrMessages.addMessage(1825361185);
            throw new MasterCraftException("Service name not specified ");
        }
        try {
          String sourcePath = System.getProperty("bancs.system.propertiespath")+"/InputFiles/ExternalServiceXML";
       //   String sourcePath = "src";
            if ((null == sourcePath) || ("".equals(sourcePath))) {
                ErrMessages.addMessage(106917, "XML file is not found ");
                return ret;
            }
            externalService = externalService + "_SERVICE_MAPPING.xml";
            ServiceMapping sm = RestAPIUtil.umarshalFromXMLToServiceObject(unmarshalledObjFromDsl, sourcePath,
                    externalService, serviceName);
            if (sm != null) {
                ret = restapicall.invokeExternalService(sm,request_url, externalServiceSb, inpVec, returnVectorObj);
            } else {
                log.error("Xml file is not Unmarshelled successfuly " );
                ErrMessages.addMessage(1825361185);
                throw new MasterCraftException("Xml file is not Unmarshelled successfuly " );

            }
        } catch (Exception e) {
            log.error("Exception Received: " + e.getMessage(), e);
            ExceptionUtil.handle(e);
            ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
        }
        if (log.isDebugEnabled()) {
            log.debug("invokeExternalService : end. returning " + ret);
        }
        return ret;
    }
}
