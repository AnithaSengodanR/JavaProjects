package com.tcs.bancs.RestApiUtility;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "ArgumentType", "ArgumentName", "ArgumentIndex", "InputSubArgumentList", "InternalField", "ExternalField",
        "ArgumentFieldType", "FieldObjectType", "ArgumentFieldList" })

public class ArgumentFields {

    @XmlElement(name = "type", required = true)
    protected String ArgumentType;
    @XmlElement(name = "name", required = true)
    protected String ArgumentName;
    @XmlElement(name = "argument-index", required = true)
    protected int ArgumentIndex;
	
	@XmlElement(name = "input-sub-argument", required = true)
    protected List<SubArgumentFields> InputSubArgumentList;
	
    @XmlElement(name = "internal-field", required = true)
    protected String InternalField;
    @XmlElement(name = "external-field", required = true)
    protected String ExternalField;
    @XmlElement(name = "field-type", required = true)
    protected String ArgumentFieldType;
    @XmlElement(name = "object-type", required = true)
    protected String FieldObjectType;

    @XmlElement(name = "argument-field", required = false)
    protected List<ArgumentFields> ArgumentFieldList;

    public String getArgumentName() {
        return ArgumentName;
    }

    public void setArgumentName(String argumentName) {
        ArgumentName = argumentName;
    }

    public int getArgumentIndex() {
        return ArgumentIndex;
    }

    public void setArgumentIndex(int argumentIndex) {
        ArgumentIndex = argumentIndex;
    }

    public String getInternalField() {
        return InternalField;
    }

    public void setInternalField(String internalField) {
        InternalField = internalField;
    }

    public String getExternalField() {
        return ExternalField;
    }

    public void setExternalField(String externalField) {
        ExternalField = externalField;
    }

    public String getArgumentType() {
        return ArgumentType;
    }

    public void setArgumentType(String argumentType) {
        ArgumentType = argumentType;
    }

    public List<ArgumentFields> getArgumentFieldList() {
        return ArgumentFieldList;
    }

    public void setArgumentFieldList(List<ArgumentFields> argumentFieldList) {
        ArgumentFieldList = argumentFieldList;
    }

    public String getArgumentFieldType() {
        return ArgumentFieldType;
    }

    public void setArgumentFieldType(String argumentFieldType) {
        ArgumentFieldType = argumentFieldType;
    }

    public String getFieldObjectType() {
        return FieldObjectType;
    }

    public void setFieldObjectType(String fieldObjectType) {
        FieldObjectType = fieldObjectType;
    }
	
	public List<SubArgumentFields> getInputSubArgumentList() {
        return InputSubArgumentList;
    }

    public void setInputSubArgumentList(List<SubArgumentFields> inpSubArgumentList) {
        InputSubArgumentList = inpSubArgumentList;
    }

}
