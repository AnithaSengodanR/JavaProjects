package com.tcs.bancs.RestApiUtility;

import java.math.BigDecimal;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.bfsarch.util.ExceptionUtil;
import com.tcs.bfsarch.webservice.errorhandler.DefaultJaxRsClientErrorHandler;
import com.tcs.bfsarch.webservice.template.JaxRsWebServiceClientTemplate;
import com.tcs.mastercraft.mctype.ErrorType;
import com.tcs.mastercraft.mctype.MasterCraftVector;
import com.tcs.mastercraft.mctype.ServerContext;
import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.MasterCraftException;

import ErrorMessages.ErrMessages;

public class RestAPICall {

   
    private static final Logger log = Logger.getLogger("BancsOnline." + RestAPICall.class);
	private static final Logger logInfo = Logger.getLogger("RestAPICallInfo." + RestAPICall.class);
    private static final String GET = "GET";
    private static final String POST = "POST";
    private static final String HEADER = "Header";
    private static final String PAGE_NUM = "PageNum";
    private static final String PAGE_SIZE = "PageSize";
    private static final String SINGLE_ROW = "SingleRow";
    private static final String MULTI_ROW = "MultiRow";
    private static final String AND = "&";
    private static final String EQUAL_TO = "=";
    private static final String QUERY = "?";
    private static final String NO_NAME = "NoName";
    private static final String USER_DEFINED = "UserDefined";
    private static final String APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded";
    private static final String PATH_SEPERATOR = "/";
	 private static final String QUERYPARAM="QueryParam";
    private static final String PATHPARAM="PathParam";
    public int flag = 0;
    HttpHeaders headers;

    public RestAPICall() {
        this.headers = new HttpHeaders();
    }

    /**
     * Invoke External Services
     * 
     * @param sm
     * @param internalServiceSb
     * @param inpVec
     * @param returnVectorObj
     * @return
     * @throws Exception
     */
    public int invokeExternalService(ServiceMapping sm,StringBuffer RequestUrl, StringBuffer internalServiceSb, MasterCraftVector inpVec,
            MasterCraftVector returnVectorObj) throws Exception 
    {
        int ret = 0;
        String internalService = internalServiceSb.toString();
        long startServiceTime = System.currentTimeMillis();

        String URL = new String();
     //   URL = sm.getURL();
        if((RequestUrl != null  && (!(RequestUrl.toString().isEmpty()))))
        {
        URL = RequestUrl.toString();
        }
        else
        {
            URL = sm.getURL();
        }
        StringBuffer URLToMethod = null;
        if (GET.equals(sm.getMethod())) {
            URLToMethod = new StringBuffer(sm.getMethod());
        }
        log.debug("sm.getInputString() :"+sm.getInputString());
        log.debug("URL BEFORE mapExternalInputObject :"+sm.getInputString());
        JSONObject inputVecForExtCall = mapExternalInputObject(sm, inpVec, URLToMethod);
		String appendedURLGET = null;
        int  ServiceId = 0 ;
        ServiceId = ARCHINFO.GetFuncId( );
		if((URLToMethod != null && GET.equals(sm.getMethod()))&& (ServiceId != 190004) && (ServiceId != 64251) && sm.getInputString()!=null )
		{
			URL = URL.concat(URLToMethod.toString());
			
		}
		else
		{
        if( (POST.equals(sm.getMethod()) || GET.equals(sm.getMethod()))) {
        	
       StringBuffer FinalURL=new StringBuffer(URL);
    
       appendedURLGET=UriBuilderForGet(sm, inpVec, URLToMethod,FinalURL);
        
            
       if(appendedURLGET != null ) 
        {
        URL = appendedURLGET;
        }
        }
        }
        long stopServiceTime = System.currentTimeMillis();
        if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
            log.debug(" Time taken for input data conversion(in milliseconds) : " + internalService + " : "
                    + (stopServiceTime - startServiceTime));
        }
        //if (URLToMethod != null) {
		if ((URLToMethod != null) && ((!"GET".equals(sm.getMethod())) && (!"POST".equals(sm.getMethod()))) || (flag == 1)) { // added as GET and POST is getting appended in the parameter value
            URL = URL.concat(URLToMethod.toString());
        }
		 log.debug("Final URL 1 :"+ URL);
        HttpMethod method = HttpMethod.POST;
        if (sm.getMethod().equals(POST)) {
            method = HttpMethod.POST;
        } else {
            if (sm.getMethod().equals(GET)) {
                method = HttpMethod.GET;
            }
        }
        try {
   
            JaxRsWebServiceClientTemplate restTemplate = new JaxRsWebServiceClientTemplate();
            HttpEntity requestEntity;
            if (APPLICATION_FORM_URLENCODED.equals(sm.getContentType()))
            {
                this.headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED); 
                restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
				requestEntity = new HttpEntity(sm.getInputString()+ EQUAL_TO +inputVecForExtCall.toString(), this.headers);
				/*
                if (((Iterator)inputVecForExtCall.keys()).hasNext()) {
                requestEntity = new HttpEntity(sm.getInputString()+ EQUAL_TO +inputVecForExtCall.toString(), this.headers);
                }
                else
                {
                	requestEntity = new HttpEntity<String>(this.headers);
                }
				*/
            }
            else
            {
                this.headers.set("Content-Type", "application/json");
				this.headers.set("accept", "application/json");
               // if(sm.getInputString()!=null) {
				requestEntity = new HttpEntity(inputVecForExtCall.toString(), this.headers);
               // }
                /*else
                {
                	requestEntity = new HttpEntity(this.headers);
                }*/
                //this.headers.setContentType(MediaType.APPLICATION_JSON);
                /*
                if (((Iterator)inputVecForExtCall.keys()).hasNext()) {
                    requestEntity = new HttpEntity(sm.getInputString()+ EQUAL_TO +inputVecForExtCall.toString(), this.headers);
                    }
                    else
                    {
                    	requestEntity = new HttpEntity<String>(this.headers);
                    }
					*/
            }
            if( log.isDebugEnabled() && ServerContext.isPrintEnabled() )
            {
            log.debug(" RequestEntity Being passed Starts :  " + requestEntity+" Ends");
            log.debug(" URL Being passed Starts :  " + URL +" Ends");
            }
			logInfo.info(" RequestEntity Being passed Starts :  " + requestEntity+" Ends");
			logInfo.info(" Method of API : "+method);
            logInfo.info(" URL Being passed Starts :  " + URL +" Ends");
            ResponseEntity response = restTemplate.exchange(URL, method, requestEntity, String.class, new Object[0]);
            if( log.isDebugEnabled() && ServerContext.isPrintEnabled() )
            {
            log.debug(" Response  Being returned Starts :  " + response +" Ends");
            }
			logInfo.info(" Response  Being returned Starts :  " + response +" Ends");
            HttpStatus statusCode = response.getStatusCode();
            if ((statusCode == HttpStatus.CREATED) || (statusCode == HttpStatus.OK) || (statusCode == HttpStatus.ACCEPTED)) 
            {
                String out = (String) response.getBody();
                if (out != null) {
                    ret = mapOutputFromExternalCall(sm, out, inpVec, returnVectorObj);
                } else {
                    ret = 1;
                }
            } else {
                if( log.isDebugEnabled() && ServerContext.isPrintEnabled() )
                {
                log.error("Invalid HTTP response. Response code:" + response.getStatusCode());
                }
                ErrMessages.addMessage(1825361185);
                throw new MasterCraftException("Invalid HTTP response. Response code:" + response.getStatusCode());
            }
       } catch(HttpClientErrorException e)
        {
          /* String s2= "";
           String[] s1 = e.getResponseBodyAsString().split(",");
           
             
                   s2 = s1[2];
           */    
           
          
       //   System.out.println("SYSOUT Error occurred while invoking External Service "+e.getResponseBodyAsString()); 
          throw new MasterCraftException("Error occurred while invoking External Web Service" + e.getResponseBodyAsString());
        } catch (Exception e) {
           DefaultJaxRsClientErrorHandler objc = new DefaultJaxRsClientErrorHandler();
           if( log.isDebugEnabled() && ServerContext.isPrintEnabled() )
           {
            log.error("Error occurred while invoking External Service" + e.getMessage());
            
           }
          
           ErrMessages.addMessage(1825361185);//1825361185
            throw new MasterCraftException("Error occurred while invoking External Web Service" + e.getMessage());
            
        }
        stopServiceTime = System.currentTimeMillis();
        if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
            log.debug(" Time taken for output data conversion(in milliseconds) : " + internalService + " : "
                    + (stopServiceTime - startServiceTime));
        }
		logInfo.info(" Time taken for output data conversion(in milliseconds) : " + internalService + " : "
                    + (stopServiceTime - startServiceTime));
        return ret;
    }

    /**
     * Map the Input objects for External service.
     * 
     * @param sm
     * @param inpVec
     * @param URL
     * @return
     * @throws Exception
     */
    private JSONObject mapExternalInputObject(ServiceMapping sm, MasterCraftVector inpVec, StringBuffer URL)
            throws Exception {
        List argList = sm.getInputArgumentList();
        JSONObject outputJson = new JSONObject();
        RestAPIUtil restAPIUtil = new RestAPIUtil();
        int pageNum = 0, pageSize = 0 , counter = 0;
        String pageNumName = null, pageSizeName = null;
       
       
        if(argList!=null) {
        for (Iterator localIterator1 = argList.iterator(); localIterator1.hasNext();) {
            Iterator localIterator2;
            //   Iterator localIterator3;
            ArgumentFields inputArgument;
            ArgumentFields headerArgumentFieldNames;
            inputArgument = (ArgumentFields) localIterator1.next();
            if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
                log.debug("argument : " + inputArgument);
            }

            String inputArgumentName = inputArgument.getArgumentName();
            if (inputArgumentName.equals(HEADER)) {
                for (localIterator2 = inputArgument.getArgumentFieldList().iterator(); localIterator2.hasNext();) {
                    headerArgumentFieldNames = (ArgumentFields) localIterator2.next();
                    String inpField = headerArgumentFieldNames.getInternalField();
                    Object inpObj = inpVec.get(inputArgument.getArgumentIndex() - 1);
                    String outputField = headerArgumentFieldNames.getExternalField();

                    if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                        Object val = restAPIUtil.getProperty(inpObj, inpField);
                        this.headers.set(outputField, val.toString());

                        // PAGE_NUM & PAGE_SIZE are needed in case these Path parameter passed in URl
                        if (inpField.equals(PAGE_NUM)) {
                            pageNum = Integer.parseInt(val.toString());
                            pageNumName = outputField;
                        }
                        if (inpField.equals(PAGE_SIZE)) {
                            pageSize = Integer.parseInt(val.toString());
                            pageSizeName = outputField;
                        }
                    }
                }
            }  
else if ((inputArgument.getArgumentFieldList() != null) && (!(inputArgument.getArgumentFieldList().isEmpty())) && !(inputArgumentName.equals(QUERYPARAM)) && !(inputArgumentName.equals(PATHPARAM))) 
{ // Below condition when Input Argument type is SingleRow
                if (inputArgument.getArgumentType().equals(SINGLE_ROW)) {
                    JSONObject Json_obj_length = new JSONObject();
                    JSONObject outputJsonRet = new JSONObject();
                    outputJsonRet = mapExternalInputObjectSingleRow(inputArgument, inpVec, URL, Json_obj_length);
                    if (Json_obj_length.length() == 0)     // Incase input to be passed in path parameter along with headers 
                    {
                        if (pageNum != 0 && pageSize != 0) {
                            URL.append(AND).append(pageNumName).append(EQUAL_TO).append(pageNum).append(AND)
                            .append(pageSizeName).append(EQUAL_TO).append(pageSize);
                        }
                    }
                    if (inputArgumentName != null)
                    {
                        // For scenario where Input requires for service without any Input object name associated with it
                        //  example
                        // { "loadId":12, "pageNo":1 }

                        if (inputArgumentName.equals(NO_NAME))        
                        {
                            // Counter is used when there are more than 1 input argument is specified with NO_NAME.
                            counter++;                  
                            if(counter > 1) {
                                JSONObject tempJson = outputJsonRet;
                                for (String name : outputJsonRet.keySet())  {
                                    outputJson.put(name, tempJson.get(name));
                                }
                            } else {
                                outputJson = outputJsonRet;  
                            }
                        } else 
                        {
                            outputJson.put(inputArgumentName, outputJsonRet);
                        }
                    }

                }  // Below condition when Input Argument type is MultiRow  
                else if (inputArgument.getArgumentType().equals(MULTI_ROW)) {
                    JSONArray JsonobjRetArray = new JSONArray();
                    JsonobjRetArray = mapExternalInputObjectMultiRow(inputArgument, inpVec);
                    outputJson.put(inputArgumentName, JsonobjRetArray);
                }
            }
else if ((inputArgument.getArgumentFieldList() == null) && (inputArgument.getInputSubArgumentList() != null))
{
	JSONObject outputJsonTemp = new JSONObject();
	for (Iterator localIterator199 = inputArgument.getInputSubArgumentList().iterator(); localIterator199.hasNext();) 
	{
		SubArgumentFields subInputArgument;
		subInputArgument = (SubArgumentFields) localIterator199.next();
		if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) 
		{
			log.debug("argument : " + inputArgument);
		}
		String subInputArgumentName = subInputArgument.getSubArgumentName();
		JSONObject Json_obj_length = new JSONObject();
		JSONObject outputJsonRet = new JSONObject();
		outputJsonRet = mapSubExternalSubInputObjectSingleRow(subInputArgument, inpVec, URL, Json_obj_length);
		
		if (subInputArgumentName != null)
		{
			// For scenario where Input requires for service without any Input object name associated with it
			//  example
			// { "loadId":12, "pageNo":1 }

			if (subInputArgumentName.equals(NO_NAME))        
			{
				// Counter is used when there are more than 1 input argument is specified with NO_NAME.
				counter++;                  
				if(counter > 1) 
				{
					JSONObject tempJson = outputJsonRet;
					for (String name : outputJsonRet.keySet())  
					{
						outputJsonTemp.put(name, tempJson.get(name));
					}
				} 
				else 
				{
					outputJsonTemp = outputJsonRet;  
				}
			} 
			else 
			{
				outputJsonTemp.put(subInputArgumentName, outputJsonRet);
			}
		}
	}
	
	outputJson.put(inputArgumentName,outputJsonTemp);
}
        }
        
        Iterator keys = outputJson.keys();
        //while(keys.hasNext()) commented as it was going in infinite loop if logging is not enabled
       // {
       if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
            try {
                if (outputJson != null) {
                    log.debug("Input vector for service call input : " + sm.getExternalServiceName() + " starts");
                   /*  String key = (String) keys.next();
                    if ((outputJson.get(key) instanceof JSONObject) && (outputJson.get(key) != null)) {
                        log.debug(outputJson.get(key).toString());
                    } commented as while is going is commented and keys.next will give errir*/
                    log.debug("Input vector for service call input : " + sm.getExternalServiceName() + " ends");
                }
            } catch (Exception e) {
                log.error("Error occurred while logging input objects");
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            }
        }
       // }
	   //Added by yamuna for defaulting page num and apge size for FXFwdContractList starts
        if (sm.getExternalServiceName().compareTo("FXFwdContractList") == 0)
		{
			outputJson.put("pageSize",22);
			//outputJson.put("pageNum:",-1);
		}
        if (sm.getExternalServiceName().compareTo("FXFwdContractList") == 0)
		{
			//outputJson.put("pageSize:",22);
			outputJson.put("pageNum",-1);
		}
        }
		//Added by yamuna for defaulting page num and apge size for FXFwdContractList	ends
        return outputJson;
    }
	
	private JSONObject mapSubExternalSubInputObjectSingleRow(SubArgumentFields inputArgumentDetails, MasterCraftVector inpVec,
            StringBuffer URL, JSONObject Json_obj) throws Exception 
	{
		JSONObject outputJson = new JSONObject();
        Iterator localIterator3;
        SubArgumentFields argumentFieldNames;
        RestAPIUtil restAPIUtil = new RestAPIUtil();
      
        Object inpObj;
        StringBuffer FinalUrl = new StringBuffer();
        JSONObject obj = new JSONObject();

        if (inputArgumentDetails.getSubArgumentIndex() != 0) 
		{
            inpObj = inpVec.get(inputArgumentDetails.getSubArgumentIndex());
        } 
		else 
		{
            // This Condition will be true when inputs to be passed in path parameters in URL
        	if(inpVec.size() > 1)//if header & input both exists
        	{
        		inpObj = inpVec.get(1);
        	}
        	else //if only input exists
        	{
        		inpObj = inpVec.get(0);
        	}
        }

        String outputField = new String();
        for (localIterator3 = inputArgumentDetails.getSubArgumentFieldList().iterator(); localIterator3.hasNext();) 
		{
            String inpField;
            int ArgumentFieldSize = inputArgumentDetails.getSubArgumentFieldList().size();
            argumentFieldNames = (SubArgumentFields) localIterator3.next();
            int index = inputArgumentDetails.getSubArgumentIndex();
			
			if (index != 0) 
			{
				JSONObject JsonobjDummy = new JSONObject();
                JSONObject JsonobjRet = new JSONObject();
                StringBuffer dummyURL = new StringBuffer();
                inpField = argumentFieldNames.getSubInternalField();
                outputField = argumentFieldNames.getSubExternalField();
				
				if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) // This condition where eventually the json Object gets Set in case of SingleRow Object 
				{  
					Object val = restAPIUtil.getProperty(inpObj, inpField);
					try 
					{
						int fieldVal = Integer.parseInt(val.toString());
						if(fieldVal !=0 )
							obj.put(outputField, val);
					} 
					catch (NumberFormatException e) 
					{
						BigDecimal ret = null;
						int flagBigDecml = 0;
						if(val instanceof BigDecimal)
						{
							ret  = (BigDecimal) val;
							flagBigDecml = 1;
						}
						else if( val instanceof BigInteger ) {
							ret = new BigDecimal( (BigInteger) val );
							flagBigDecml = 1;

						}
						if(flagBigDecml == 1)
						{
							if(ret.compareTo(new BigDecimal("0.0")) != 0 )
							{
								obj.put(outputField, ret);
							}
						}
						else
						{
							obj.put(outputField, val);
						}
					}
				}
			}
		}
		if (obj.length() != 0) 
		{
			outputJson = obj;
			Json_obj.put(outputField, obj);
        } 
		else 
		{
            URL.delete(0, 3);
            URL.append(FinalUrl);
        }

        return outputJson;
	}
	private String UriBuilderForGet(ServiceMapping sm, MasterCraftVector inpVec, StringBuffer URL,StringBuffer FinalURL)
            throws Exception {
        List argList = sm.getInputArgumentList();
        log.debug("UriBuilderForGet method is called");
       RestAPIUtil restAPIUtil = new RestAPIUtil();
       if(argList!=null) {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(FinalURL.toString());
        Map<String ,String> UrlParams=new HashMap<>();
		    for (Iterator localIterator1 = argList.iterator(); localIterator1.hasNext();) {
            Iterator localIterator2;
          
            ArgumentFields inputArgument;
            ArgumentFields headerArgumentFieldNames;
            inputArgument = (ArgumentFields) localIterator1.next();
            if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
                log.debug("argument : " + inputArgument);
            }

            String inputArgumentName = inputArgument.getArgumentName();
            
            if (inputArgumentName.equals(QUERYPARAM)) {
				flag = 1;
                // Below condition when Input Argument type is SingleRow           	
                if (inputArgument.getArgumentType().equals(SINGLE_ROW)) {
                    JSONObject Json_obj_length = new JSONObject();
                    JSONObject outputJsonRet = new JSONObject();
                    outputJsonRet = mapExternalInputObjectSingleRow(inputArgument, inpVec, URL, Json_obj_length);
                    Iterator keys=outputJsonRet.keys();
                                       
                    while(keys.hasNext()) {
                    	
                    	try {
                            if (outputJsonRet != null) {
                                log.debug("Query Param appending to the URL: " + sm.getExternalServiceName() + " starts");
                                String key = (String) keys.next();
                               
                              if (outputJsonRet.get(key).toString().length()>0 && key != null) {	
                                    log.debug(outputJsonRet.get(key).toString());
                                    
                                    uriBuilder.queryParam(key,outputJsonRet.get(key));
                                 
                                }
                                log.debug("Query Param appending to the URL: " + sm.getExternalServiceName() + " ends");
                            }
                    	}
                    	
                    	catch (Exception e) {
                    	    log.error("Error occurred while appending input objects as query parameters");
                            ExceptionUtil.handle(e);
                            ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
                        }
                    	
                    
                    	
                    }
                    

                }
                
            }      
            
            
            else if (inputArgumentName.equals(PATHPARAM)) {
                // Below condition when Input Argument type is SingleRow 
            	
                if (inputArgument.getArgumentType().equals(SINGLE_ROW)) {
                    JSONObject Json_obj_length = new JSONObject();
                    JSONObject outputJsonRet = new JSONObject();
                    outputJsonRet = mapExternalInputObjectSingleRow(inputArgument, inpVec, URL, Json_obj_length);
                   
                    Iterator keys=outputJsonRet.keys();
                   
                    while(keys.hasNext()) {
                    	
                    	try {
                            if (outputJsonRet != null) {
                                log.debug("Path Param appending to the URL: " + sm.getExternalServiceName() + " starts");
                                String key = (String) keys.next();
                                
                               
                              if (outputJsonRet.get(key).toString().length()>0 && key != null) {	
                                    log.debug(outputJsonRet.get(key).toString());
                                    
                                   UrlParams.put(key,outputJsonRet.get(key).toString());
                                
                                }
                                log.debug("Path Param appending to the URL: " + sm.getExternalServiceName() + " ends");
                            }
                    	}
                    	
                    	catch (Exception e) {
                    		
                            log.error("Error occurred while appending input objects as path parameters");
                            ExceptionUtil.handle(e);
                            ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
                        }
                    	
                    
                    }
                    

                }
                           
            } 
			}
            
        
       
        return uriBuilder.buildAndExpand(UrlParams).toUriString();
       }
       else
    	   return null;
    }

    /**
     * Map the Input objects for External service for Single Row.
     * 
     * @param argumentFields
     * @param inpVec
     * @param URL
     * @param Json_obj
     * @return
     * @throws Exception
     */
    private JSONObject mapExternalInputObjectSingleRow(ArgumentFields inputArgumentDetails, MasterCraftVector inpVec,
            StringBuffer URL, JSONObject Json_obj) throws Exception {
        JSONObject outputJson = new JSONObject();
        Iterator localIterator3;
        ArgumentFields argumentFieldNames;
        RestAPIUtil restAPIUtil = new RestAPIUtil();
      
        Object inpObj;
        StringBuffer FinalUrl = new StringBuffer();
        JSONObject obj = new JSONObject();

        if (inputArgumentDetails.getArgumentIndex() != 0) {
            inpObj = inpVec.get(inputArgumentDetails.getArgumentIndex() - 1);
        } else {
            // This Condition will be true when inputs to be passed in path parameters in URL
        	if(inpVec.size() > 1)//if header & input both exists
        	{
        		inpObj = inpVec.get(1);
        	}
        	else //if only input exists
        	{
        		inpObj = inpVec.get(0);
        	}
        }

        String outputField = new String();
        for (localIterator3 = inputArgumentDetails.getArgumentFieldList().iterator(); localIterator3.hasNext();) {
            String inpField;
            int ArgumentFieldSize = inputArgumentDetails.getArgumentFieldList().size();
            argumentFieldNames = (ArgumentFields) localIterator3.next();
            int index = inputArgumentDetails.getArgumentIndex();

            if (URL != null) {
                if (URL.toString().equals(GET)) {
                    if (index == 0) {                           // Scenario when Input to be passed in Path parameters in URL 

                        if (ArgumentFieldSize > 1) {                            //When  more than 1 field to be passed as input in Path parameters in URL 
                            inpField = argumentFieldNames.getInternalField();
                            outputField = argumentFieldNames.getExternalField();
                            if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                                Object val = restAPIUtil.getProperty(inpObj, inpField);
                                if (val != null) {
                                    if (FinalUrl.length() == 0) {
                                        String urlForm = FinalUrl.toString().concat(QUERY);
                                        FinalUrl.append(urlForm);
                                        urlForm = outputField + EQUAL_TO + val;
                                        FinalUrl.append(urlForm);
                                    } else {
                                        String urlForm2 = AND + outputField + EQUAL_TO + val;
                                        FinalUrl.append(urlForm2);
                                    }
                                }
                            }
                        } else if (ArgumentFieldSize == 1) {                     // When only 1 field to be passed as input in Path parameters in URL 
                            inpField = argumentFieldNames.getInternalField();
                            outputField = argumentFieldNames.getExternalField();
                            if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                                Object val = restAPIUtil.getProperty(inpObj, inpField);
                                
                                FinalUrl.append(PATH_SEPERATOR);
                                FinalUrl.append(val);
                            }

                        }

                    }
                }
            }
            if (index != 0) {                               // When input object to be passed as message Body  
                JSONObject JsonobjDummy = new JSONObject();
                JSONObject JsonobjRet = new JSONObject();
                StringBuffer dummyURL = new StringBuffer();
                inpField = argumentFieldNames.getInternalField();
                outputField = argumentFieldNames.getExternalField();

                String ArgumentFieldType = argumentFieldNames.getArgumentFieldType();
                String FieldObjetcType = argumentFieldNames.getFieldObjectType();

             // Below condition when input object is of Custom Defined Type (eg. class Employee)  
                if (FieldObjetcType != null && FieldObjetcType.equals(USER_DEFINED)) { 
                    // Condtion when  Custom_Defined_Type input object is Single Row 
                    if (ArgumentFieldType != null && ArgumentFieldType.equals(SINGLE_ROW)) 
                    {                                                                         
                        MasterCraftVector inpVecNewSin = new MasterCraftVector();

                        if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                            Object val = restAPIUtil.getProperty(inpObj, inpField);
                            inpVecNewSin.add(val);
                            JsonobjRet = mapExternalInputObjectSingleRow(argumentFieldNames, inpVecNewSin, dummyURL,
                                    JsonobjDummy);
                            obj.put(outputField, JsonobjRet);
                        }

                    } else if (ArgumentFieldType != null && ArgumentFieldType.equals(MULTI_ROW))  // When  Custom Defined Type input object is Multirow 
                    {
                        MasterCraftVector inpVecNewMul = new MasterCraftVector();
                        JSONArray JsonobjRetArray = new JSONArray();
                        if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                            MasterCraftVector val = restAPIUtil.getPropertyMasterVector(inpObj, inpField);
                            inpVecNewMul.add(val);
                            JsonobjRetArray = mapExternalInputObjectMultiRow(argumentFieldNames, inpVecNewMul);
                            obj.put(outputField, JsonobjRetArray);
                        }
                    }
                } else { // Below condition when input object is not of Custom Defined Type (eg. Integer/StringBuffer multirow)  
                    if (ArgumentFieldType != null && ArgumentFieldType.equals(MULTI_ROW))
                    {
                        MasterCraftVector ObjectInput = new MasterCraftVector();
                        JSONArray ArrayObjectJson = new JSONArray();
                        if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) 
                        {
                            ObjectInput  = restAPIUtil.getPropertyMasterVector(inpObj, inpField);
                        }

                        for(int l=0;l<ObjectInput.size();l++)
                        {
                            ArrayObjectJson.put(l, ObjectInput.get(l));
                        }
                        obj.put(outputField, ArrayObjectJson);
                    }
                    else 
                        if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) { // This condition where eventually the json Object gets Set in case of SingleRow Object  
							
                            Object val = restAPIUtil.getProperty(inpObj, inpField);
							if(val != null)
							{
                            try {
                                int fieldVal = Integer.parseInt(val.toString());
                                if(fieldVal !=0 )
                                    obj.put(outputField, val);
                                } catch (NumberFormatException e) {
                                BigDecimal ret = null;
                                int flagBigDecml = 0;
                                if(val instanceof BigDecimal)
                                {
                                    ret  = (BigDecimal) val;
                                    flagBigDecml = 1;
                                }
                                else if( val instanceof BigInteger ) {
                                    ret = new BigDecimal( (BigInteger) val );
                                    flagBigDecml = 1;

                                }
                                if(flagBigDecml == 1)
                                {
                                    if(ret.compareTo(new BigDecimal("0.0")) != 0 )
                                    {
                                        obj.put(outputField, ret);
                                    }
                                }
                                else
                                    obj.put(outputField, val);
								}
							}
                        }
                }
            }
        }
        if (obj.length() != 0) {

            outputJson = obj;

            Json_obj.put(outputField, obj);
        } else {
            URL.delete(0, 3);
            URL.append(FinalUrl);
        }

        return outputJson;
    }

    /**
     * Map the Input objects for External service for Multiple Row.
     * 
     * @param argumentFields
     * @param inpVec
     * @return
     * @throws Exception
     */
    private JSONArray mapExternalInputObjectMultiRow(ArgumentFields argumentFields, MasterCraftVector inpVec)
            throws Exception {
        JSONArray outputJson = new JSONArray();
        JSONArray fieldNameArray = new JSONArray();
        Iterator localIterator3;
        ArgumentFields argumentFieldNames;
        RestAPIUtil restAPIUtil = new RestAPIUtil();

        String outputExternalField = argumentFields.getExternalField();

        MasterCraftVector inpObjMultirow = (MasterCraftVector) inpVec.get(argumentFields.getArgumentIndex() - 1);
        JSONArray object = new JSONArray();
        int counter = 0;
        for (int j = 0; j < inpObjMultirow.size(); j++) {
            JSONObject obj = new JSONObject();
            Object inpObj = inpObjMultirow.get(j);
            for (localIterator3 = argumentFields.getArgumentFieldList().iterator(); localIterator3.hasNext();) {
                String inpField;
                String outputField;

                argumentFieldNames = (ArgumentFields) localIterator3.next();
                int index = argumentFields.getArgumentIndex();
                if (index == 0) {
                    inpField = argumentFieldNames.getInternalField();
                    outputField = argumentFieldNames.getExternalField();
                    try {
                        int fieldVal = Integer.parseInt(inpField);
                        obj.put(outputField, fieldVal);
                    } catch (NumberFormatException e) {
                        obj.put(outputField, inpField);
                    }
                } else {
                    inpField = argumentFieldNames.getInternalField();
                    outputField = argumentFieldNames.getExternalField();
                    if (restAPIUtil.checkPropertySpecified(inpObj, inpField)) {
                        Object val = restAPIUtil.getProperty(inpObj, inpField);
                        //if (outputExternalField.equals(outputField)) {//commented as it is throwing null pointer exception and added null check
                        if (outputField!=null && outputExternalField!=null && outputExternalField.equals(outputField)) {
                                                   fieldNameArray.put(counter, val);
                            counter++;
                        } else {
                            obj.put(outputField, val);
                        }
                    }
                }
            }


            object.put(j, obj);
        }
        if (counter > 0) {
            return fieldNameArray;
        }
        outputJson = object;
        return outputJson;
    }

    /**
     * Map the response
     * 
     * @param sm
     * @param outputJsonObjct
     * @param treasuryCallInputVector
     * @param returnVectorObj
     * @return
     * @throws Exception
     */
    private int mapOutputFromExternalCall(ServiceMapping sm, String outputJsonObjct,
            MasterCraftVector treasuryCallInputVector, MasterCraftVector returnVectorObj) throws Exception {
        int outObj = 0;
        MasterCraftVector outPutVector = new MasterCraftVector();
        for (int i = 0; i < returnVectorObj.size(); i++) {
            outPutVector.append(returnVectorObj.get(i));
            }
      
        ObjectMapper objectMapper = new ObjectMapper();
      
        JsonNode parentNode = (JsonNode) objectMapper.readValue(outputJsonObjct, JsonNode.class);
        List argList = sm.getOutputArgumentList();
        if ((argList == null) || (argList.isEmpty())) {
            return outObj;
        }
     
        for (Iterator returnArgument = argList.iterator(); returnArgument.hasNext();) {
            ArgumentFields Outpuargument = (ArgumentFields) returnArgument.next();
            Iterator childNode = parentNode.fields();
            Iterator childNodeNames = parentNode.fieldNames();
            if( log.isDebugEnabled() && ServerContext.isPrintEnabled() ) {
                log.debug("argument : " + Outpuargument);
            }
            int NoNameFlag = 0;
            int ObjectIndex = Outpuargument.getArgumentIndex() - 1;
            Object outputObjNoNAME = outPutVector.get(ObjectIndex);
            while (childNode.hasNext()) {
                String childNodeName = (String) childNodeNames.next();
                String className = Outpuargument.getArgumentName();
                Map.Entry child = (Map.Entry) childNode.next();
                JsonNode value = (JsonNode) child.getValue();

                if(className.equals(NO_NAME))
                {

                    NoNameFlag = 1;
                    if (value.isArray()) {
                        MasterCraftVector returnVec = new MasterCraftVector();
                        System.out.println("value is Array");
                        for (JsonNode arrayItem : value) {
                            setFieldvaluesToNoNameOutput(Outpuargument,childNodeName,arrayItem,outputObjNoNAME);
                            returnVec.append(outputObjNoNAME);
                        }
                        if (returnVec.size() != 0 && returnVec.get(0) != null) {
                            outObj = 1;
                        }
                        returnVectorObj.set(ObjectIndex, returnVec);
                    } else 
                    {
                        setFieldvaluesToNoNameOutput(Outpuargument,childNodeName,value,outputObjNoNAME);
                    }


                }else if (childNodeName.equals(className)) {
                        Iterator innerChild;
                        if (value.isObject()) {
                            Object outputObj = outPutVector.get(ObjectIndex);
                            setFieldvaluesToNoNameOutput(Outpuargument,childNodeName,value,outputObj);
                            returnVectorObj.set(ObjectIndex, outputObj);
                            if (outputObj != null) {
                                outObj = 1;
                            }
                        } else if (value.isArray()) {
                            MasterCraftVector returnVec = new MasterCraftVector();
                            MasterCraftVector outVecObjInit = (MasterCraftVector) outPutVector.get(ObjectIndex);
                            Class outVecObj1 = outVecObjInit.get(0).getClass();
                            for (JsonNode arrayItem : value) {
                                Object outVecObj = outVecObj1.newInstance();
                                setFieldvaluesToNoNameOutput(Outpuargument,childNodeName,arrayItem,outVecObj);
                                returnVec.append( outVecObj);
                            }
                            if (returnVec.size() != 0 && returnVec.get(0) != null) {
                                outObj = 1;
                            }
                            returnVectorObj.set(ObjectIndex, returnVec);
                        }
                    }
            }
            if(NoNameFlag == 1)
            {
                if (outputObjNoNAME != null) {
                    outObj = 1;
                }
                returnVectorObj.set(ObjectIndex, outputObjNoNAME);
            }
        }
        return outObj;
    }


    private void setFieldvaluesToNoNameOutput( ArgumentFields Outpuargument,String childNodeName ,JsonNode value,Object outputObjNoNAME )
    {

        String className = Outpuargument.getArgumentName();

        if(className.equals(NO_NAME))
        {
            if ((Outpuargument.getArgumentFieldList() != null)
                    && (!(Outpuargument.getArgumentFieldList().isEmpty()))) {
                for (ArgumentFields argumentFields : Outpuargument.getArgumentFieldList()) {

                    String inpField = argumentFields.getInternalField();
                    String outputField = argumentFields.getExternalField();
                    if (childNodeName.equals(outputField)) {
                        getValueOfFields(value,inpField,outputObjNoNAME);
                    }
                }
            }
        } else
        {
            Iterator innerChild;
            if ((Outpuargument.getArgumentFieldList() != null)
                    && (!(Outpuargument.getArgumentFieldList().isEmpty()))) {

                for (ArgumentFields argumentFields : Outpuargument.getArgumentFieldList()) {
                    innerChild = value.fields();
                    while (innerChild.hasNext()) {
                        Map.Entry entry = (Map.Entry) innerChild.next();
                        String keyField = (String) entry.getKey();
                        JsonNode  valueField = (JsonNode) entry.getValue();
                        String inpField = argumentFields.getInternalField();
                        String outputField = argumentFields.getExternalField();

                        if (keyField.equals(outputField)) {

                            getValueOfFields(valueField,inpField,outputObjNoNAME);
                        }
                    }
                }
            }
        }
    }




    private void getValueOfFields( JsonNode FieldValue, String inpField ,Object outVecObj )
    {

        RestAPIUtil restAPIUtil = new RestAPIUtil();

        if (FieldValue.isInt()) {
            int Intval = FieldValue.asInt();
            restAPIUtil.setPropertyToInternalObject(Intval, inpField, outVecObj);
        } else if (FieldValue.isTextual()) {
            String OtherFieldval = FieldValue.textValue();
			 if(OtherFieldval != null && OtherFieldval != "")
            {
            restAPIUtil.setPropertyToInternalObject(OtherFieldval, inpField,
                    outVecObj);
					}
					
        } else if (FieldValue.isDouble()) {
            Object values = FieldValue.asDouble();
            restAPIUtil.setPropertyToInternalObject(values, inpField, outVecObj);
        }
    }


}