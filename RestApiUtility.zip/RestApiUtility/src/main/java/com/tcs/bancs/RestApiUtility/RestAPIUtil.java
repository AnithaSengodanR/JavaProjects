package com.tcs.bancs.RestApiUtility;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import com.tcs.bfsarch.util.ExceptionUtil;
import com.tcs.mastercraft.mctype.MasterCraftDate;
import com.tcs.mastercraft.mctype.MasterCraftVector;
import com.tcs.mastercraft.mctype.ServerContext;

import ErrorMessages.ErrMessages;

public class RestAPIUtil {

    private static final String GET = "get";
    private static final String ISSPECIFIED = "isSpecified";
    private static final String MASTER_CRAFT_DATE = "MasterCraftDate";
    private static final String STRING_BUFFER = "StringBuffer";
    private static final String BIG_DECIMAL = "BigDecimal";
    private static final Logger log = Logger.getLogger("BancsOnline." + RestAPIUtil.class);

    /**
     * Unmarshalling XML Data to Service Object
     * 
     * @param unmarshalledObjFromDsl
     * @param sourcePath
     * @param enrichedDslName
     * @param serviceName
     * @return
     */
    public static ServiceMapping umarshalFromXMLToServiceObject(ServiceMapping unmarshalledObjFromXML,
            String sourcePath, String enrichedXMLName, String serviceName) {
        StringBuilder xmlPath = new StringBuilder(sourcePath);
        xmlPath.append(File.separator).append(enrichedXMLName);
        File file = new File(xmlPath.toString());
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { ServiceMapping.class });
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            unmarshalledObjFromXML = (ServiceMapping) jaxbUnmarshaller.unmarshal(file);
        } catch (JAXBException e) {
            ErrMessages.addMessage(106917, "Error while unmarshalling the enriched XML " + serviceName + ".xml");
            log.error("Failed to unmarshal enriched XML" + serviceName + ".xml" + e.getMessage());
            return null;
        }
        JAXBContext jaxbContext;
        return unmarshalledObjFromXML;
    }

    /**
     * Verify property defined in XML exists in Object
     * 
     * @param inpObj
     * @param inpField
     * @return
     */
    public boolean checkPropertySpecified(Object inpObj, String inpField) {
        boolean ret = false;
        try {
            Class InputClassName = Class.forName(inpObj.getClass().getName());
            Field FeildName = InputClassName.getDeclaredField(inpField);
            if (FeildName != null) {
                ret = true;
            }
        } catch (Exception e) {
            log.error("Exception Received: " + e.toString(), e);
            ExceptionUtil.handle(e);
            ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            
        }
        return ret;
    }

    /**
     * Get value of property
     * 
     * @param inpObj
     * @param inpField
     * @return
     */
    public Object getProperty(Object inpObj, String inpField) {
        Object fieldValue = null;
        if (inpField != null) {
            PropertyDescriptor pd = null;
            try {
                Class InputClassName = Class.forName(inpObj.getClass().getName());
                Object clsInstance;
                clsInstance = InputClassName.newInstance();
                clsInstance = inpObj;
                Method fieldGetterMethod = null;
                
                Method fieldSpecMethod = null;
                int isSpecified = 1;

                Field FeildName = InputClassName.getDeclaredField(inpField);
                try {
                    pd = new PropertyDescriptor(inpField, inpObj.getClass());
                } catch (IntrospectionException e) {
                    e.printStackTrace();
                }
				if(pd.getPropertyType().getSimpleName().equals(MASTER_CRAFT_DATE))
				{
					fieldSpecMethod = InputClassName.getMethod(ISSPECIFIED + inpField, new Class[0]);
					isSpecified = Integer.parseInt(fieldSpecMethod.invoke(clsInstance, new Object[0]).toString());
				}
                if (FeildName != null) {
                    fieldGetterMethod = InputClassName.getMethod(GET + inpField, new Class[0]);
                    if (!((pd.getPropertyType().isPrimitive()) && (pd.getPropertyType().getSimpleName().equals(STRING_BUFFER)) && (pd.getPropertyType().getSimpleName().equals(MASTER_CRAFT_DATE)))) {
                        if(isSpecified == 1)
                        {
                        	fieldValue = fieldGetterMethod.invoke(clsInstance, new Object[0]);
                        }
                    } else {
                    	if(isSpecified == 1) 
                    	{
                    		fieldValue = fieldGetterMethod.invoke(clsInstance, new Object[0]).toString();
                    	}
                    }

                }
            } catch (InstantiationException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (NoSuchMethodException e) {
                //log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (IllegalAccessException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (IllegalArgumentException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (InvocationTargetException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (ClassNotFoundException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (NoSuchFieldException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            } catch (SecurityException e) {
                log.error("Exception Received: " + e.toString(), e);
                ExceptionUtil.handle(e);
                ServerContext.addMessage(1825361185, 4, ExceptionUtil.getRootCause(e));
            }
        }
        return fieldValue;
    }

    /**
     * Set property value in Internal object.
     * 
     * @param FieldValue
     * @param inpField
     * @param inpObj
     */
    public Object setPropertyToInternalObject(Object FieldValue, String inpField,  Object inpObj) {
        boolean propertyCheckFlg = false;
       
        propertyCheckFlg = checkPropertySpecified(inpObj, inpField);
    
        
        if (propertyCheckFlg == true) {
            PropertyDescriptor pd;
            try {
                pd = new PropertyDescriptor(inpField, inpObj.getClass());
                if (!(pd.getPropertyType().isPrimitive())) {
                    if (pd.getPropertyType().getSimpleName().equals(STRING_BUFFER)) {
                        FieldValue = new StringBuffer(FieldValue+"");//When field value is primitive ,it is not getting converted to stringBuffer. So instead of type casting to a string the value has been converted to string by adding double quotes.
                    }
                    if (pd.getPropertyType().getSimpleName().equals(MASTER_CRAFT_DATE)) {
                        MasterCraftDate Mastrcftdate = new MasterCraftDate();
                        String separator1 = "-";
                        String separator2 = "/";
                        if( (((String) FieldValue).contains(separator1)) || (((String) FieldValue).contains(separator2)) )
                        {
                        	String finSeparator = "";
                        	if(((String) FieldValue).contains(separator1))
                        	{
                        		finSeparator = separator1;
                        	}
                        	
                        	if(((String) FieldValue).contains(separator2))
                        	{
                        		finSeparator = separator2;
                        	}
                        	String dd = "";
                        	String mm = "";
                        	String yyyy = "";
                        	String newFormatWithoutSep = "";
                        	int count = 1;
                        	for(String tempStr : ((String)FieldValue).split(finSeparator))
                        	{
                        		if(count == 1)
                        		{
                        			dd = tempStr;
                        		}
                        		if(count == 2)
                        		{
                        			mm = tempStr;
                        		}
                        		if(count == 3)
                        		{
                        			yyyy = tempStr;
                        		}
                        		count++;
                        	}
                        	newFormatWithoutSep = yyyy+mm+dd;
                        	Mastrcftdate.setDate(newFormatWithoutSep);
                        	FieldValue = Mastrcftdate;
                        }
                        else
                        {
                        	Mastrcftdate.setDate((String) FieldValue);
                        	FieldValue = Mastrcftdate;
                        }
                    }
					if (pd.getPropertyType().getSimpleName().equals(BIG_DECIMAL)) {

                       if(FieldValue instanceof Number)
                        {
                             FieldValue = BigDecimal.valueOf( ((Number)FieldValue).doubleValue());
                        }

                     }
                }
             pd.getWriteMethod().invoke(inpObj, FieldValue);
             }catch (IntrospectionException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        
        return inpObj;
    }

    /**
     * Get property value from MasterCraft object
     * 
     * @param inpObj
     * @param inpField
     * @return
     */
    public MasterCraftVector getPropertyMasterVector(Object inpObj, String inpField) {
        MasterCraftVector fieldValue = null;
        if (inpField != null) {
            try {
                Class InputClassName = Class.forName(inpObj.getClass().getName());
                Object clsInstance;
                clsInstance = InputClassName.newInstance();
                clsInstance = inpObj;
                Method fieldGetterMethod = null;
                Field FeildName = InputClassName.getDeclaredField(inpField);
                if (FeildName != null) {
                    fieldGetterMethod = InputClassName.getMethod(GET + inpField, new Class[0]);
                    fieldValue = (MasterCraftVector) fieldGetterMethod.invoke(clsInstance, new Object[0]);
                }
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }

        return fieldValue;
    }

}
