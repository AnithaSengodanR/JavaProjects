package com.tcs.bancs.RestApiUtility;

public class Header {
    String Accesstoken;
    int ChannelType;
    int CoRelationid;
    String InitiatingSystem;
    int ServiceMode;
    int UUIDSeqNo;
    String ApplicationId;
    StringBuffer Entity;
    int LanguageCode;
    int PageNum;
    int PageSize;
    String ReferenceId;
    int UserId;
    String Requesthash;

    public String getAccesstoken() {
        return Accesstoken;
    }

    public void setAccesstoken(String accesstoken) {
        Accesstoken = accesstoken;
    }

    public int getChannelType() {
        return ChannelType;
    }

    public void setChannelType(int channelType) {
        ChannelType = channelType;
    }

    public int getCoRelationid() {
        return CoRelationid;
    }

    public void setCoRelationid(int coRelationid) {
        CoRelationid = coRelationid;
    }

    public String getInitiatingSystem() {
        return InitiatingSystem;
    }

    public void setInitiatingSystem(String initiatingSystem) {
        InitiatingSystem = initiatingSystem;
    }

    public int getServiceMode() {
        return ServiceMode;
    }

    public void setServiceMode(int serviceMode) {
        ServiceMode = serviceMode;
    }

    public int getUUIDSeqNo() {
        return UUIDSeqNo;
    }

    public void setUUIDSeqNo(int uUIDSeqNo) {
        UUIDSeqNo = uUIDSeqNo;
    }

    public String getApplicationId() {
        return ApplicationId;
    }

    public void setApplicationId(String applicationId) {
        ApplicationId = applicationId;
    }

    public StringBuffer getEntity() {
        return Entity;
    }

    public void setEntity(StringBuffer entity) {
        Entity = entity;
    }

    public int getLanguageCode() {
        return LanguageCode;
    }

    public void setLanguageCode(int languageCode) {
        LanguageCode = languageCode;
    }

    public int getPageNum() {
        return PageNum;
    }

    public void setPageNum(int pageNum) {
        PageNum = pageNum;
    }

    public int getPageSize() {
        return PageSize;
    }

    public void setPageSize(int pageSize) {
        PageSize = pageSize;
    }

    public String getReferenceId() {
        return ReferenceId;
    }

    public void setReferenceId(String referenceId) {
        ReferenceId = referenceId;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getRequesthash() {
        return Requesthash;
    }

    public void setRequesthash(String requesthash) {
        Requesthash = requesthash;
    }
}