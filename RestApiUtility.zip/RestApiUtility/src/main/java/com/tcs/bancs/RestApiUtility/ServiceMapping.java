package com.tcs.bancs.RestApiUtility;

import java.util.ArrayList;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "ExternalServiceName", "ExternalServiceType", "Method", "URL","ContentType","InputString", "InputArgumentList",
        "OutputArgumentList" })
@XmlRootElement(name = "ServiceMapping")
public class ServiceMapping {

    @XmlElement(name = "external-service-name", required = true)
    protected String ExternalServiceName;
    @XmlElement(name = "external-service-type", required = true)
    protected String ExternalServiceType;
    @XmlElement(name = "external-method", required = true)
    protected String Method;
    @XmlElement(name = "request-url", required = true)
    protected String URL;
    @XmlElement(name = "content-type", required = true)
    protected String ContentType;
    @XmlElement(name = "input-string", required = true)
    protected String InputString;
    @XmlElement(name = "input-argument", required = true)
    protected List<ArgumentFields> InputArgumentList;
    @XmlElement(name = "output-argument", required = true)
    protected List<ArgumentFields> OutputArgumentList;

    public String getURL() {
        return URL;
    }

    public void setURL(String uRL) {
        URL = uRL;
    }

    public String getExternalServiceName() {
        return ExternalServiceName;
    }

    public void setExternalServiceName(String externalServiceName) {
        ExternalServiceName = externalServiceName;
    }

    public String getExternalServiceType() {
        return ExternalServiceType;
    }

    public void setExternalServiceType(String externalServiceType) {
        ExternalServiceType = externalServiceType;
    }

    public String getMethod() {
        return Method;
    }

    public void setMethod(String method) {
        Method = method;
    }

    public List<ArgumentFields> getInputArgumentList() {
        return InputArgumentList;
    }

    public void setInputArgumentList(List<ArgumentFields> inputArgumentList) {
        InputArgumentList = inputArgumentList;
    }

    public List<ArgumentFields> getOutputArgumentList() {
        return OutputArgumentList;
    }

    public void setOutputArgumentList(List<ArgumentFields> outputArgumentList) {
        OutputArgumentList = outputArgumentList;
    }

    public void setInputArgumentList(int index, ArgumentFields obj) {

        List<ArgumentFields> InputArgumentListObj = new ArrayList<ArgumentFields>();
        InputArgumentListObj.add(index, obj);
        InputArgumentList = InputArgumentListObj;
    }

    public String getContentType() {
        return ContentType;
    }

    public void setContentType(String contentType) {
        ContentType = contentType;
    }

    public String getInputString() {
        return InputString;
    }

    public void setInputString(String inputString) {
        InputString = inputString;
    }
    
    
}
