package com.tcs.bancs.RestApiUtility;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "SubArgumentType", "SubArgumentName", "SubArgumentIndex", "SubInternalField", "SubExternalField",
        "SubArgumentFieldType", "SubFieldObjectType", "SubArgumentFieldList" })

public class SubArgumentFields {

    @XmlElement(name = "subtype", required = true)
    protected String SubArgumentType;
    @XmlElement(name = "subname", required = true)
    protected String SubArgumentName;
    @XmlElement(name = "subargument-index", required = true)
    protected int SubArgumentIndex;	
    @XmlElement(name = "subinternal-field", required = true)
    protected String SubInternalField;
    @XmlElement(name = "subexternal-field", required = true)
    protected String SubExternalField;
    @XmlElement(name = "subfield-type", required = true)
    protected String SubArgumentFieldType;
    @XmlElement(name = "subobject-type", required = true)
    protected String SubFieldObjectType;

    @XmlElement(name = "subargument-field", required = false)
    protected List<SubArgumentFields> SubArgumentFieldList;

    public String getSubArgumentName() {
        return SubArgumentName;
    }

    public void setSubArgumentName(String subArgumentName) {
        SubArgumentName = subArgumentName;
    }

    public int getSubArgumentIndex() {
        return SubArgumentIndex;
    }

    public void setSubArgumentIndex(int subArgumentIndex) {
        SubArgumentIndex = subArgumentIndex;
    }

    public String getSubInternalField() {
        return SubInternalField;
    }

    public void setSubInternalField(String subInternalField) {
        SubInternalField = subInternalField;
    }

    public String getSubExternalField() {
        return SubExternalField;
    }

    public void setSubExternalField(String subExternalField) {
        SubExternalField = subExternalField;
    }

    public String getSubArgumentType() {
        return SubArgumentType;
    }

    public void setSubArgumentType(String subArgumentType) {
        SubArgumentType = subArgumentType;
    }

    public List<SubArgumentFields> getSubArgumentFieldList() {
        return SubArgumentFieldList;
    }

    public void setSubArgumentFieldList(List<SubArgumentFields> subArgumentFieldList) {
        SubArgumentFieldList = subArgumentFieldList;
    }

    public String getSubArgumentFieldType() {
        return SubArgumentFieldType;
    }

    public void setSubArgumentFieldType(String subArgumentFieldType) {
        SubArgumentFieldType = subArgumentFieldType;
    }

    public String getSubFieldObjectType() {
        return SubFieldObjectType;
    }

    public void setSubFieldObjectType(String subFieldObjectType) {
        SubFieldObjectType = subFieldObjectType;
    }

}
